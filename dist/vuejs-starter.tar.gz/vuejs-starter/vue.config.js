module.exports = {
  chainWebpack: config => {
    config.externals({
    })
  }
}
