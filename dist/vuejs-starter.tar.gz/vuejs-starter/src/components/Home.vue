<template>
    <div>
        <p>Home</p>
    </div>
</template>
<style lang="scss">
</style>
