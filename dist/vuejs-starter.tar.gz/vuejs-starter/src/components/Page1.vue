<template>
    <div>
        <p>Page 1</p>
    </div>
</template>
<script>
    export default {

    }
</script>
