<template>
    <div>
        <p>Page 2</p>
    </div>
</template>
<script>
  export default {

  }
</script>
